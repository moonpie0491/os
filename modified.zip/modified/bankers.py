# Banker's Safety Algorithm in Python

# Function to check if the system is in a safe state
def is_safe(processes, available, max_demand, allocated, need):
    num_processes = len(processes)
    num_resources = len(available)

    # Mark all processes as not finished
    finish = [False] * num_processes
    safe_sequence = []

    # Work is a copy of available resources
    work = available[:]

    while len(safe_sequence) < num_processes:
        safe_found = False
        for p in range(num_processes):
            if not finish[p]:
                # Check if process can be satisfied with available resources
                if all(need[p][r] <= work[r] for r in range(num_resources)):
                    # If yes, pretend to allocate resources to this process
                    for r in range(num_resources):
                        work[r] += allocated[p][r]
                    safe_sequence.append(p)
                    finish[p] = True
                    safe_found = True
                    break

        if not safe_found:
            # No safe sequence found
            return False, []

    return True, safe_sequence


# Driver code
if __name__ == "__main__":
    # Number of processes
    num_processes = int(input("Enter the number of processes: "))
    
    # Process IDs (e.g., P0, P1, P2...)
    processes = [i for i in range(num_processes)]

    # Number of resource types
    num_resources = int(input("Enter the number of resource types: "))

    # Available resources
    available = list(map(int, input(f"Enter {num_resources} available resources (space-separated): ").split()))

    # Maximum demand for each process
    max_demand = []
    for i in range(num_processes):
        demand = list(map(int, input(f"Enter maximum demand for Process {i} (space-separated): ").split()))
        max_demand.append(demand)

    # Allocated resources for each process
    allocated = []
    for i in range(num_processes):
        allocation = list(map(int, input(f"Enter allocated resources for Process {i} (space-separated): ").split()))
        allocated.append(allocation)

    # Calculate the need matrix: max_demand - allocated
    need = []
    for i in range(num_processes):
        need.append([max_demand[i][j] - allocated[i][j] for j in range(len(available))])

    # Print input details
    print("\nProcesses:", processes)
    print("Available Resources:", available)
    print("Max Demand Matrix:", max_demand)
    print("Allocated Resources Matrix:", allocated)
    print("Need Matrix:", need)
    print()

    # Check system safety
    safe, safe_sequence = is_safe(processes, available, max_demand, allocated, need)

    if safe:
        print("System is in a safe state.")
        print("Safe sequence is:", safe_sequence)
    else:
        print("System is NOT in a safe state!")
