import matplotlib.pyplot as plt
import matplotlib.patches as mpatches

def plot_gantt_chart(processes, timeline):
    fig, gnt = plt.subplots()

    gnt.set_xlabel('Time')
    gnt.set_ylabel('Processes')

    unique_processes = sorted(set(p for p, _ in timeline))

    gnt.set_yticks([10 * (i + 1) for i in range(len(unique_processes))])
    gnt.set_yticklabels([f'P{pid}' for pid in unique_processes])

    gnt.set_xlim(0, max(t for _, t in timeline) + 1)
    gnt.set_ylim(0, 10 * (len(unique_processes) + 1))

    colors = ['red', 'green', 'blue', 'orange', 'purple']
    for pid, start in timeline:
        gnt.broken_barh([(start, 1)], (10 * (pid) - 5, 9), facecolors=(colors[(pid - 1) % len(colors)]))

    handles = [mpatches.Patch(color=colors[i % len(colors)], label=f'P{i + 1}') for i in range(len(unique_processes))]
    plt.legend(handles=handles)

    plt.title("Gantt Chart")
    plt.show()

def preemptive_priority(processes):
    n = len(processes)
    processes.sort(key=lambda x: (x[1], x[3]))

    current_time = 0
    finish_times = [0] * n
    remaining_burst = [burst for _, _, burst, _ in processes]
    timeline = []

    while True:
        idx = -1
        highest_priority = float('inf')
        for i, (pid, arrival, burst, priority) in enumerate(processes):
            if arrival <= current_time and remaining_burst[i] > 0 and priority < highest_priority:
                highest_priority = priority
                idx = i

        if idx == -1:
            current_time += 1
            continue

        remaining_burst[idx] -= 1
        timeline.append((processes[idx][0], current_time))

        if remaining_burst[idx] == 0:
            finish_times[idx] = current_time + 1

        current_time += 1

        if all(burst == 0 for burst in remaining_burst):
            break

    turnaround_times = [finish_times[i] - processes[i][1] for i in range(n)]
    waiting_times = [turnaround_times[i] - processes[i][2] for i in range(n)]

    print("\n{:<10}{:<10}{:<10}{:<10}{:<10}{:<15}{:<10}".format(
        "Process", "Arrival", "Burst", "Priority", "Finish", "Turnaround", "Waiting"
    ))

    for i, (pid, arrival, burst, priority) in enumerate(processes):
        print("{:<10}{:<10}{:<10}{:<10}{:<10}{:<15}{:<10}".format(
            f"P{pid}", arrival, burst, priority, finish_times[i], turnaround_times[i], waiting_times[i]
        ))

    plot_gantt_chart(processes, timeline)

# Input from user
def get_user_input():
    num_processes = int(input("Enter the number of processes: "))
    processes = []
    for i in range(num_processes):
        print(f"\nProcess {i + 1}:")
        pid = i + 1
        arrival = int(input("Enter arrival time: "))
        burst = int(input("Enter burst time: "))
        priority = int(input("Enter priority (lower number = higher priority): "))
        processes.append((pid, arrival, burst, priority))
    return processes

# Main
if __name__ == "__main__":
    processes = get_user_input()
    preemptive_priority(processes)
