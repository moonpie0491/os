#include <stdio.h>

int in(int size, int *array, int value) {
    for (int i = 0; i < size; i++) {
        if (array[i] == value)
            return 1; // Return 1 if the page is found
    }
    return 0; // Return 0 if the page is not found
}

int closestIndex(int size, int currentLocation, int *array, int value, int direction) {
    if (direction == -1) { // For LRU
        for (int i = currentLocation - 1; i >= 0; i--) {
            if (array[i] == value)
                return i;
        }
    } else { // For Optimal
        for (int i = currentLocation + 1; i < size; i++) {
            if (array[i] == value)
                return i;
        }
    }
    return (direction == -1) ? -1 : size; // Return -1 or size if not found
}

int extreme(int size, int *array, int type) {
    int extreme = 0; // Default to first index
    if (type == 1) { // max
        for (int i = 1; i < size; i++) {
            if (array[i] > array[extreme]) {
                extreme = i; // Update to max index
            }
        }
    } else { // min
        for (int i = 1; i < size; i++) {
            if (array[i] < array[extreme]) {
                extreme = i; // Update to min index
            }
        }
    }
    return extreme;
}

void printArray(int size, int *array) {
    for (int i = 0; i < size; i++) {
        printf("%d ", array[i]);
    }
    printf("\n");
}

int main() {
    int n; // Number of page requests
    printf("Enter number of page requests: ");
    scanf("%d", &n);
    int m; // Number of pages in memory
    printf("Enter number of pages: ");
    scanf("%d", &m);
    int currPages[m]; // Array to hold current pages
    int pageRequests[n]; // Array to hold page requests

    printf("Enter the page requests separated by space: \n");
    for (int i = 0; i < n; i++) {
        scanf("%d", &pageRequests[i]); // Read page requests
    }

    // FIFO
    int faults = 0, hits = 0, index = 0; // Use index to track the next page to replace
    for (int i = 0; i < m; i++) {
        currPages[i] = -1; // Initialize memory to -1
    }

    printf("\nFIFO:\n");
    for (int i = 0; i < n; i++) {
        if (in(m, currPages, pageRequests[i])) {
            hits++;
            printf("Request: %d - Hit (Pages in memory: ", pageRequests[i]);
        } else {
            currPages[index] = pageRequests[i]; // Replace page
            index = (index + 1) % m; // Move to the next index in circular fashion
            faults++;
            printf("Request: %d - Fault (Pages in memory: ", pageRequests[i]);
        }
        // Print current pages in memory
        printArray(m, currPages);
    }

    printf("\tTotal Pages: %d\n", n);
    printf("\tPage faults: %d\n", faults);
    printf("\tPage Hits: %d\n", hits);
    printf("\tHit Ratio: %.2f%%\n", (hits * 100.0) / n);
    printf("\tMiss Ratio: %.2f%%\n", (faults * 100.0) / n);

    // Optimal
    faults = 0; hits = 0; index = 0; 
    for (int i = 0; i < m; i++) {
        currPages[i] = -1; // Initialize memory to -1
    }
    int nextIndex[m]; // Array to hold next usage indexes
    int filledBlocks = 0; // Number of filled blocks

    printf("\nOptimal:\n");
    for (int i = 0; i < n; i++) {
        if (in(filledBlocks, currPages, pageRequests[i])) {
            hits++;
            printf("Request: %d - Hit (Pages in memory: ", pageRequests[i]);
        } else {
            if (filledBlocks == m) {
                for (int j = 0; j < m; j++) {
                    nextIndex[j] = closestIndex(n, i, pageRequests, currPages[j], 1);
                }
                int farest = extreme(m, nextIndex, 1); // Get index of furthest page
                currPages[farest] = pageRequests[i]; // Replace it
            } else {
                currPages[filledBlocks++] = pageRequests[i]; // Fill new page
            }
            faults++;
            printf("Request: %d - Fault (Pages in memory: ", pageRequests[i]);
        }
        // Print current pages in memory
        printArray(m, currPages);
    }

    printf("\tTotal Pages: %d\n", n);
    printf("\tPage Faults: %d\n", faults);
    printf("\tPage Hits: %d\n", hits);
    printf("\tHit Ratio: %.2f%%\n", (hits * 100.0) / n);
    printf("\tMiss Ratio: %.2f%%\n", (faults * 100.0) / n);
    
    // LRU
    /* faults = 0; hits = 0; index = 0; 
    for (int i = 0; i < m; i++) {
        currPages[i] = -1; // Initialize memory to -1
    }
    int prevIndex[m]; // Array to hold previous usage indexes

    printf("\nLRU:\n");
    for (int i = 0; i < n; i++) {
        if (in(m, currPages, pageRequests[i])) {
            hits++;
            printf("Request: %d - Hit (Pages in memory: ", pageRequests[i]);
        } else {
            if (filledBlocks == m) {
                for (int j = 0; j < m; j++) {
                    prevIndex[j] = closestIndex(n, i, pageRequests, currPages[j], -1);
                }
                int leastRecent = extreme(m, prevIndex, -1); // Get index of least recently used page
                currPages[leastRecent] = pageRequests[i]; // Replace it
            } else {
                currPages[filledBlocks++] = pageRequests[i]; // Fill new page
            }
            faults++;
            printf("Request: %d - Fault (Pages in memory: ", pageRequests[i]);
        }
        // Print current pages in memory
        printArray(m, currPages);
    }

    printf("\tTotal Pages: %d\n", n);
    printf("\tPage Faults: %d\n", faults);
    printf("\tPage Hits: %d\n", hits);
    printf("\tHit Ratio: %.2f%%\n", (hits * 100.0) / n);
    printf("\tMiss Ratio: %.2f%%\n", (faults * 100.0) / n);
    
    printf("\n");
    */
    return 0;
    
}
